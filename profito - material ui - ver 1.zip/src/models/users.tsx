export type UserSession = {
  email: string;
  name: string;
};
