import React, { FunctionComponent } from "react";

const Registration: FunctionComponent = (props) => {
  return <>{props.children}</>;
};

export default Registration;
