import React from "react";
import Integrate from "./_integrate";

export default function Edit() {
  return (
    <React.Fragment>
      <Integrate />
    </React.Fragment>
  );
}
