import { ThemeOptions } from "@material-ui/core";

export const theme: ThemeOptions = {};
